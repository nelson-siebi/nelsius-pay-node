const Nelsius = require('./index');

console.log("--- Nelsius Node.js SDK Test ---");

// Configuration
const apiKey = 'sk_live_L8L1W438xaoBGxTEzD0qBnpkwxrtvJGWKPbVsj88CFhJzrXw69fNPjFEANsDUWPy'; // Validated test key
const baseUrl = 'http://127.0.0.1:8000/api/v1';

const nelsius = new Nelsius(apiKey, {
    baseUrl: baseUrl
});

async function runTests() {
    try {
        // 1. Get Payment Methods
        console.log("\n1. Fetching payment methods...");
        const methods = await nelsius.charges.methods();
        console.log(`Found ${methods.data ? methods.data.length : 0} payment methods.`);

        // 2. Get Balance
        console.log("\n2. Fetching balance...");
        const balance = await nelsius.balance.get();
        console.log(`Current Balance: ${balance.data ? balance.data.balance : 0} ${balance.data ? balance.data.currency : 'XAF'}`);

        // 3. Create Checkout Session
        console.log("\n3. Creating checkout session...");
        const checkout = await nelsius.checkout.createSession({
            amount: 5000,
            currency: 'XAF',
            reference: 'TEST_NODE_REF_' + Date.now(),
            description: 'Test Node.js SDK Purchase',
            return_url: 'https://example.com/success',
            cancel_url: 'https://example.com/cancel',
            customer: {
                email: 'customer@example.com',
                name: 'Node JS SDK Tester'
            }
        });

        if (checkout.data && checkout.data.checkout_url) {
            console.log(`Checkout Session Created: ${checkout.data.checkout_url}`);
        } else {
            console.log("Checkout Session Creation Failed:", JSON.stringify(checkout));
        }

        // 4. Create Direct Charge
        console.log("\n4. Creating direct charge...");
        try {
            const charge = await nelsius.charges.create({
                amount: 2500,
                currency: 'XAF',
                method: 'mobile_money',
                operator: 'orange',
                customer_phone: '690000000',
                reference: 'TEST_NODE_CHARGE_' + Date.now(),
                description: 'Test Direct Charge Node.js SDK'
            });

            if (charge.data && charge.data.charge_id) {
                console.log(`Direct Charge Created: ${charge.data.charge_id}`);
            } else {
                console.log(`Direct Charge Status: ${charge.message || 'Pending'}`);
            }
        } catch (chargeError) {
            console.log("Charge Creation (expected possible timeout):", chargeError.message);
        }

        console.log("\n--- All Node.js SDK tests completed ---");

    } catch (error) {
        console.error("\nERROR:", error.data || error.message);
    }
}

runTests();
